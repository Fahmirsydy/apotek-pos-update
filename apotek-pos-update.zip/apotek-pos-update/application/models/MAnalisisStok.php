<?php

class MAnalisisStok extends CI_Model
{
    private $product = "produk";
    private $golongan = "golongan_obat";
    private $satuan = "satuan_obat";
    private $penjualanProduct = "penjualan_produk";
    private $penjualan = "penjualan";
    private $users = "users";
    private $pembelian = "pembelian";
    private $pembelianProduct = "pembelian_produk";

    // First In First Out (FIFO)
    public function getStokObatByTanggalMasuk($start, $end){
      $this->db->select('pp.id_produk, pr.nama_produk, SUM(pp.pembelian) as stok');
      $this->db->from('pembelian p');
      $this->db->join('pembelian_produk pp', 'p.id_pembelian = pp.id_pembelian');
      $this->db->join('produk pr', 'pr.id_produk = pp.id_produk');
      $this->db->where('p.tanggal_pembelian >=', $start);
      $this->db->where('p.tanggal_pembelian <=', $end);
      $this->db->group_by(['pp.id_produk', 'pr.nama_produk']);

      $query = $this->db->get();
      return $query->result();
    }
    
    // First Expired First Out (FEFO)
    public function getStokObatByTanggalExpired($start, $end){
      $this->db->select('pp.id_produk, pr.nama_produk, SUM(pp.pembelian) as stok');
      $this->db->from('pembelian p');
      $this->db->join('pembelian_produk pp', 'p.id_pembelian = pp.id_pembelian');
      $this->db->join('produk pr', 'pr.id_produk = pp.id_produk');
      $this->db->where('pp.expire_date >=', $start);
      $this->db->where('pp.expire_date <=', $end);
      $this->db->group_by(['pp.id_produk', 'pr.nama_produk']);

      $query = $this->db->get();
      return $query->result();
    }
}
