<script>
            function printDiv(divName) {
                var printContents = document.getElementById(divName).innerHTML;
                var originalContents = document.body.innerHTML;

                document.body.innerHTML = printContents;

                window.print();

                document.body.innerHTML = originalContents;
            }

            $(function () {

                <?php
                    $barcolors = ["#2ecc71", "#3498db"];
                    function generateRandomHexColor() {
                        return sprintf('#%06X', mt_rand(0, 0xFFFFFF));
                    }

                    $data = array();
                    foreach($stoks as $stok){
                        $dataset = [
                            'id' => $stok->id_produk,
                            'label' => $stok->nama_produk,
                            'stok' => $stok->stok
                        ];

                        $data[] = $dataset;
                    }

                ?>

                new Chart(document.getElementById("analisis-chart"), {
                    type: 'bar',
                    data: {
                        labels: [
                            <?php 
                                for($i=0; $i<sizeof($data);$i++){
                                    echo "'".$data[$i]['label']."'";
                                    if($i<sizeof($data) && $i!=sizeof($data)-1){
                                        echo ',';
                                    }
                                }
                            ?>
                        ],
                        datasets: [
                            {
                            label: "Stok",
                            backgroundColor: [
                                <?php 
                                    for($i=0; $i<sizeof($data);$i++){
                                        if($i<sizeof($barcolors)){
                                            echo "'".$barcolors[$i]."'";
                                        }
                                        else{
                                            echo "'".generateRandomHexColor()."'";
                                        }
                                        if($i<sizeof($data) && $i!=sizeof($data)-1){
                                            echo ',';
                                        }
                                    }
                                ?>
                            ],
                            data: [
                                <?php 
                                    for($i=0; $i<sizeof($data);$i++){
                                        echo $data[$i]['stok'];
                                        if($i<sizeof($data) && $i!=sizeof($data)-1){
                                            echo ',';
                                        }
                                    }
                                ?>
                            ]
                            }
                        ]
                    },
                    options: {
                        legend: { display: false },
                        title: {
                            display: true, 
                            text: '<?= $label ?>'
                        },
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        }
                    }
                });

                $('#grafik_fifo_btn').on('click', function(){
                    $('#grafik_type').val('fifo');
                    $('#form-grafik').submit();
                });
                $('#grafik_fefo_btn').on('click', function(){
                    $('#grafik_type').val('fefo');
                    $('#form-grafik').submit();
                });
            })
        </script>