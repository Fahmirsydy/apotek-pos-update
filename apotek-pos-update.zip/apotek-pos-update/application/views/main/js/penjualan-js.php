<script src="<?php echo base_url().'assets/extra-libs/c3/d3.min.js'?>"></script>
<script src="<?php echo base_url().'assets/extra-libs/c3/c3.min.js'?>"></script>
<script src="<?php echo base_url().'assets/libs/chartist/dist/chartist.min.js'?>"></script>
<script src="<?php echo base_url().'assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js'?>"></script>
<script src="<?php echo base_url().'assets/extra-libs/jvector/jquery-jvectormap-2.0.2.min.js'?>"></script>
<script src="<?php echo base_url().'assets/extra-libs/jvector/jquery-jvectormap-world-mill-en.js'?>"></script>
<script src="<?php echo base_url().'assets/dist/js/pages/dashboards/dashboard1.min.js'?>"></script>