
<script src="<?php echo base_url().'/assets/dist/js/pages/chartjs/chartjs.init.js'?>"></script>
<script src="<?php echo base_url().'/assets/libs/chart.js/dist/Chart.min.js'?>"></script>