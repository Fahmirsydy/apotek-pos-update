<script src="<?php echo base_url().'assets/libs/jquery/dist/jquery.min.js'?>"></script>
<script src="<?php echo base_url().'assets/libs/popper.js/dist/umd/popper.min.js'?>"></script>
<script src="<?php echo base_url().'assets/libs/bootstrap/dist/js/bootstrap.min.js'?>"></script>
<script src="<?php echo base_url().'assets/dist/js/app-style-switcher.js'?>"></script>
<script src="<?php echo base_url().'assets/dist/js/feather.min.js'?>"></script>
<script src="<?php echo base_url().'assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js'?>"></script>
<script src="<?php echo base_url().'assets/extra-libs/sparkline/sparkline.js'?>"></script>
<script src="<?php echo base_url().'assets/dist/js/sidebarmenu.js'?>"></script>
<script src="<?php echo base_url().'assets/dist/js/custom.min.js'?>"></script>

