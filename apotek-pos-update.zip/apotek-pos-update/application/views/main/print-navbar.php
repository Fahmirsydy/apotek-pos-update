<nav class="navbar top-navbar navbar-expand-md" style="text-align:center;">
    <div class="navbar-header" data-logobg="skin6">
        <button class="btn btn-primary" type="button" onclick="printDiv('print')"><i class="fas fa-print"></i> Kembali</button>
    </div>
</nav>