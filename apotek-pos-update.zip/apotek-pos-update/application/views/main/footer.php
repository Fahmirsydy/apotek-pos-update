<footer class="footer text-center text-muted">
    <!-- Designed by <a
        href="https://wrappixel.com">WrapPixel</a> and Developed by Denis Yordan P. -->
</footer>